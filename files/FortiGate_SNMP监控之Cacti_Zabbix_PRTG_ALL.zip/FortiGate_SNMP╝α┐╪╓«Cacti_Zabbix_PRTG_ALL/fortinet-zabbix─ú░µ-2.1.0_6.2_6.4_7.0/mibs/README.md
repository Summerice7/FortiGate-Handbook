# MIBs

| MIB                                     | Version       | Build |
|-----------------------------------------|---------------|-------|
| FORTINET-CORE-MIB                       | 6.4.0         | b1579 |
| FORTINET-FORTIGATE-MIB                  | 6.4.0         | b1579 |
| FORTINET-FORTIMANAGER-FORTIANALYZER-MIB | 6.4.0         | b2002 |
| FORTINET-FORTIAP-MIB                    | 6.4.0 interim | b0416 |

<!-- 
## MIB Child OID report generation

To track template completion I'll list and flag what specific OIDs are
already being used on the corresponding template.

    $ snmptranslate -Tz -IR -m +FORTINET-FORTIGATE-MIB > FORTINET-FORTIGATE-MIB.csv -->
